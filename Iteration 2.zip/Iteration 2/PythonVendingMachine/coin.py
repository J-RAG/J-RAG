# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Coin

class Coin:
    def __init__(self, newalloy, newdiameter, newweight, newvalue):
        self.alloy = newalloy
        self.diameter = newdiameter
        self.weight = newweight
        self.value = newvalue

#    def toCoinTableRow():
#        """
#            Specified in UML Class diagram
#            (to be developed)
#        """
#        pass

# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Product

class Product:
    def __init__(self, newname, newcolour, newweight, newprice):
        self.name = newname
        self.colour = newcolour
        self.weight = newweight
        self.price = newprice

#    def toProductTableRow():
#        """
#            Specified in UML Class diagram
#            (to be developed)
#        """
#        pass
        
